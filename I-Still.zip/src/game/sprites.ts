export type Sprites = {
  playerWalk: HTMLImageElement;
  playerIdle: HTMLImageElement;
  eye: HTMLImageElement;
  shard: HTMLImageElement;
  props: HTMLImageElement;
  door: HTMLImageElement;
  moth: HTMLImageElement;
  floor: HTMLImageElement;
};

function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`Failed to load ${src}`));
    img.src = src;
  });
}

export async function loadSprites(): Promise<Sprites> {
  const [playerWalk, playerIdle, eye, shard, props, door, moth, floor] = await Promise.all([
    loadImage("/sprites/player-walk.png"),
    loadImage("/sprites/player-idle.png"),
    loadImage("/sprites/eye.png"),
    loadImage("/sprites/shard.png"),
    loadImage("/sprites/props.png"),
    loadImage("/sprites/door.png"),
    loadImage("/sprites/moth.png"),
    loadImage("/art/floor.jpg"),
  ]);
  return { playerWalk, playerIdle, eye, shard, props, door, moth, floor };
}
